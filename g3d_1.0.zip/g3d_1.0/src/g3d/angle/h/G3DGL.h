#ifndef IW_ANGLE_GL_H
#define IW_ANGLE_GL_H

#include "EGL\egl.h"
#include "EGL\eglext.h"
#include "EGL\eglplatform.h"

#include "GLES2\gl2.h"
#include "GLES2\gl2ext.h"
#include "GLES2\gl2platform.h"

#endif