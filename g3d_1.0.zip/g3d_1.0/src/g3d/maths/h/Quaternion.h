#ifndef G3D_MATHS_QUATERNION_H
#define G3D_MATHS_QUATERNION_H

class CG3DQuaternion {
public:
	float x;
	float y;
	float z;
	float w;
};

#endif