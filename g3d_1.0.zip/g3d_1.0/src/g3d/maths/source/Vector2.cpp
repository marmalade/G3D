#include "Maths.h"

CG3DVector2 CG3DVector2::s_Zero(0, 0);
CG3DVector2 CG3DVector2::s_One(1, 1);
CG3DVector2 CG3DVector2::s_UnitX(1, 0);
CG3DVector2 CG3DVector2::s_UnitY(0, 1);