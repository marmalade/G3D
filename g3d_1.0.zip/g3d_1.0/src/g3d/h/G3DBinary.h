#ifndef G3D_BINARY_H
#define G3D_BINARY_H

// Optional binary loading classes

#include "Binary.h"

#endif