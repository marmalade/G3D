#ifndef IW_G3D_ANGLE_H
#define IW_G3D_ANGLE_H

#include "IwG3DCore.h"

#include "SystemAngle.h"

#endif