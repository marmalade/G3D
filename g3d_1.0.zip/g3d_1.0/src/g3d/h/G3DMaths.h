#ifndef G3D_MATHS_H
#define G3D_MATHS_H

// 3D Mathematics classes, including vector, matrix and colour classes

#include "Colour.h"
#include "Maths.h"

#endif