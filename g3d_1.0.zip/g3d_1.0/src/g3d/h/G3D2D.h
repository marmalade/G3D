#ifndef G3D_2D_H
#define G3D_2D_H

// Optional set of classes, embodying a hierarchy of 2d objects
// and visual scenes

#include "2dobject.h"

#endif