#ifndef IW_G3D_WIN32_H
#define IW_G3D_WIN32_H

#include "G3DCore.h"

// Call this to make the implementation for Marmalade
CG3DSystem* MakeG3DSystemWin32();

#endif